Sound work by Astrid Seme in collaboration with Sizwe Mthethwa and Thapelo Kotlai, Johannesburg.


“A Book for All Readers” has been published in an anthology of the same title in the late 19th century. The book is conceived as a guide to the formation of libraries and the collection, use, and preservation of books. The poem appears in the chapter ‘humors of the library’.

Rap, a style inherited from poetry, shifts the printed words to “A Song for All Readers”. Rhyming the oration of the sacred librarian line by line is reminiscent of common practices in protest movements and keeps on demanding #FreeEducationForAll and an open access to knowledge for future readers.


A BOOK FOR ALL READERS

Know by heart all mens’ biography,
And the black art of typography,
And every book in bibliography.
These things are all essential
And highly consequential.
If he’s haunted by ambition
For a library position,
And esteems it a high mission,
To aspire to erudition;
He will find some politician
Of an envious disposition.
Getting up a coalition
To secure his non-admission,
And send him to perdition,
Before he’s reached fruition.
If he gets the situation,
And is full of proud elation
And of fond anticipation.
And has in contemplation
To enlighten half the nation.
He may write a dissertation
For the public information
On the laws of observation.
And the art of conversation.
He must know each famed oration,
And poetical quotation,
And master derivation,
And the science of translation,
And complex pagination,
And perfect punctuation,
And binomial equation.
And accurate computation.
And boundless permutation,
And infinite gradation.
And the craft of divination,
And Scripture revelation,
And the secret of salvation.
He must know the population
Of every separate nation.


cover typeface: Dosage (The Pyte Foundry) by Ellmer Stefan


